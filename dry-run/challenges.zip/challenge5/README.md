# Challenge 5

Our informant is satisfied with our communication through his server. Though, he
decided to ramp up security a bit and only send messages in parts. He wants
you to connect to new server `challenge5@10.31.1.161` and use the cookie retrieved
from the previous communication. Now you need to get the key with a length of `20`
in pieces. He conceived a new message protocol. You need to send him the key from
the previous communication along with the position of the key you want. Oh, and
he needs your process ID to send a message back. This all needs to be placed in
a tuple in the exact order and as I've explained. In our final message our informant
told us that he rented a cheaper service to reduce costs. The server has an delay
of 5 seconds, but can handle many requests at once. Al this is done by
`Challenge5.secret()` on his server.
