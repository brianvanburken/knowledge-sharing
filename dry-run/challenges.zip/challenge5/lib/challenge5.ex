defmodule Challenge5 do
  def get_key() do
    # your implementation here!
  end
end
