defmodule Challenge6 do
  def get_key() do
    # your implementation here!
  end
end
