defmodule Challenge1 do
  @doc """
  Decodes our secret emoji language to human-readable ASCII strings

  ## Examples

      iex> Challenge1.decode("😀😱😜😫😜")
      "AVISI"

  """
  def decode(string) do
    # your implementation here!
  end
end
