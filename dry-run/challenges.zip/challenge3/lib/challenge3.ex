defmodule Challenge3 do
  def repair(file_name) do
    # your implementation here!
  end
end
