# Challenge 4

Our informant got tired of creating zips and corrupting them. He got the idea to
let you connect to a server he set up. He wants you send a message to his server.
He expects you send a tuple with the atom :secret and ofcourse your process ID to
receive an answer back. The server is called `challenge4@10.31.1.161`, the cookie
is the previous key, and the secret function you can call is `Challenge4.secret()`.
