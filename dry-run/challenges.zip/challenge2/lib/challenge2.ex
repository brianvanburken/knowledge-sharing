defmodule Challenge2 do
  def parse(file_name) do
    # your implementation here!
  end
end
